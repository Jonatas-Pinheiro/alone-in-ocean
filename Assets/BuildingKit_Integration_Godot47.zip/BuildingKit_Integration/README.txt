ALONE IN OCEAN — INTEGRAÇÃO DO BUILDING & PLACEMENT KIT
Godot 4.7.2

CONTEÚDO
- Scenes/Building/BuildingCatalog.gd
- Scenes/Building/BuildingKitBootstrap.gd

O pacote espera que o addon já esteja em:
res://addons/building_kit/

E que as quatro cenas tenham estes caminhos exatos:
res://Scenes/Building/Pieces/Floor.tscn
res://Scenes/Building/Pieces/Wall.tscn
res://Scenes/Building/Pieces/Ramp.tscn
res://Scenes/Building/Pieces/Ceiling.tscn

INSTALAÇÃO ÚNICA
1. Copie a pasta Scenes/Building deste pacote para a pasta Scenes/Building do projeto.
2. Na cena principal, crie um Node3D chamado BuildingKitSetup.
3. Anexe BuildingKitBootstrap.gd a esse nó.
4. No Inspector, atribua:
   - Player Camera: a Camera3D usada pelo Player.
   - Raft Root: o nó raiz Node3D da jangada.
   - Terrain Mask: 1 (camada física 1, onde precisa estar o collider da jangada).
   - Placed Piece Layer: 2 (camada física 2, usada nas peças construídas).
5. Salve e execute a cena.

A interface PKBuildHUD é criada automaticamente. Selecione uma peça no catálogo inferior.
Com a mira no centro da tela:
- Clique esquerdo / Enter: construir.
- R / Shift+R: girar.
- Clique direito / Esc: cancelar e guardar a ferramenta.
- 1 a 6: modos construir, mover, demolir, selecionar, melhorar e reparar.
- Ctrl+Z: desfazer.

CONFIGURAÇÃO DAS CENAS 3D
O addon interpreta a origem de cada cena como o centro da base da peça, no nível do chão.
Portanto:
- Floor.tscn: a base da cena fica em Y=0; a geometria de 0,3 m fica centralizada em Y=0,15.
- Wall.tscn: a base fica em Y=0; a parede sobe até Y=3.
- Ramp.tscn: a base traseira fica em Y=0, com o meio da largura no X=0.
- Ceiling.tscn: a face inferior fica em Y=0.

DIMENSÕES USADAS NAS REGRAS
- Piso: AABB 3 x 0,3 x 3 m; grade 3 x 3.
- Parede: AABB 2,7 x 3 x 0,3 m; grade 3 x 1. A malha real continua com 3 m de largura; a caixa de validação é menor para evitar falso bloqueio em cantos.
- Rampa: AABB padrão 3 x 3 x 3 m; grade 3 x 3. Ajustável em Ramp Bounds no Inspector.
- Teto: AABB padrão 3 x 0,3 x 3 m; grade 3 x 3. Ajustável em Ceiling Bounds no Inspector.

IMPORTANTE — LIMITES DESTA INTEGRAÇÃO
- As peças estão sem custo configurado; por enquanto, a construção é gratuita.
- O kit funciona localmente. A replicação das construções entre clientes ainda NÃO está ligada ao GD-Sync. O bootstrap impede que um cliente multiplayer crie construções locais divergentes; a ponte RPC/autoridade do host é uma etapa separada.
- O sistema do addon trabalha com coordenadas globais. Esta configuração assume a jangada posicionada e alinhada ao eixo global ao iniciar. A movimentação/rotação da jangada durante a construção exige adaptar a conversão de coordenadas e a persistência das peças; não está sendo declarada como resolvida aqui.
- O collider da jangada precisa estar na camada física 1, e as peças precisam usar a camada física 2. Se o collider da jangada estiver em outra camada, altere Terrain Mask no Inspector.
- O pivot de Raft Root é usado como referência da grade. O offset padrão (-0,5, 0, -0,5) assume que o pivot está no centro da jangada e que a célula da grade mede 1 m.
